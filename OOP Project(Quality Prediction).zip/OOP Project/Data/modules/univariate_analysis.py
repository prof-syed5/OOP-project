import seaborn as sns
import matplotlib.pyplot as plt

class UnivariateAnalysis:
    def __init__(self, data):
        self.data = data

    def histogram(self, column):
        sns.histplot(self.data[column], kde=True)
        plt.title(f"Histogram of {column}")
        plt.show()
