import seaborn as sns
import matplotlib.pyplot as plt

class BivariateAnalysis:
    def __init__(self, data):
        self.data = data

    def correlation_heatmap(self):
        sns.heatmap(self.data.corr(), annot=True, cmap='coolwarm')
        plt.title("Correlation Heatmap")
        plt.show()
