class DataUnderstanding:
    def __init__(self, data):
        self.data = data

    def overview(self):
        print("Shape:", self.data.shape)
        print("Data types:\n", self.data.dtypes)
        print("Missing values:\n", self.data.isnull().sum())
        print("Summary:\n", self.data.describe(include='all'))

    def unique_values(self, column):
        print(f"Unique values in '{column}': {self.data[column].unique()}")
