# Test DataCollector
from data_collector import DataCollector
collector = DataCollector("winequality-red.csv")
data = collector.load_data()
collector.get_data_summary()

# Test ModelTrainer with simple SVM
from data_preprocessing import DataPreprocessor
from model_trainer import ModelTrainer

preprocessor = DataPreprocessor(data)
X_train, X_test, y_train, y_test = preprocessor.split_data('quality')

trainer = ModelTrainer()
trainer.train(X_train, y_train)
accuracy = trainer.evaluate(X_test, y_test)
print(f"\n Model Accuracy: {accuracy:.2f}")

# Test ModelStorage
from model_storage import ModelStorage

ModelStorage.save_model(trainer.model, "wine_model_temp.pkl")
print(" Model saved as 'wine_model_temp.pkl'")

loaded_model = ModelStorage.load_model("wine_model_temp.pkl")
print(" Model loaded successfully")
