import matplotlib.pyplot as plt
import seaborn as sns

class Visualiser:
    def __init__(self, data):
        self.data = data

    def plot_feature_vs_target(self, feature, target):
        sns.boxplot(x=self.data[target], y=self.data[feature])
        plt.title(f"{feature} vs {target}")
        plt.show()
