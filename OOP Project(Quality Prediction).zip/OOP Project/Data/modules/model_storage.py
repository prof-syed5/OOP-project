import pickle

class ModelStorage:
    @staticmethod
    def save_model(model, filename):
        with open(filename, 'wb') as f:
            pickle.dump(model, f)

    @staticmethod
    def load_model(filename):
        with open(filename, 'rb') as f:
            return pickle.load(f)
