from sklearn.model_selection import train_test_split

class DataPreprocessor:
    def __init__(self, data):
        self.data = data

    def split_data(self, target_column, test_size=0.2, random_state=42):
        X = self.data.drop(target_column, axis=1)
        y = self.data[target_column]
        return train_test_split(X, y, test_size=test_size, random_state=random_state)
