import streamlit as st
import numpy as np
import pickle

class WineModel:
    def __init__(self, model_path='wine_model.pkl'):
        self.model = self.load_model(model_path)

    def load_model(self, model_path):
        with open(model_path, 'rb') as file:
            return pickle.load(file)

    def predict_quality(self, features):
        features = np.array(features).reshape(1, -1)
        return self.model.predict(features)[0]

class WineApp:
    def __init__(self):
        self.model = WineModel()

    def run(self):
        st.set_page_config(page_title="Wine Quality Predictor", layout="centered")
        st.title("Wine Quality Predictor (Streamlit GUI)")
        st.write("Enter the following wine characteristics:")

        fixed_acidity = st.number_input("Fixed Acidity", 4.0, 16.0, 7.4)
        volatile_acidity = st.number_input("Volatile Acidity", 0.1, 1.5, 0.7)
        citric_acid = st.number_input("Citric Acid", 0.0, 1.0, 0.0)
        residual_sugar = st.number_input("Residual Sugar", 0.5, 15.0, 1.9)
        chlorides = st.number_input("Chlorides", 0.01, 0.2, 0.076)
        free_sulfur_dioxide = st.number_input("Free Sulfur Dioxide", 1.0, 70.0, 11.0)
        total_sulfur_dioxide = st.number_input("Total Sulfur Dioxide", 6.0, 300.0, 34.0)
        density = st.number_input("Density", 0.9900, 1.0050, 0.9978)
        pH = st.number_input("pH", 2.8, 4.0, 3.51)
        sulphates = st.number_input("Sulphates", 0.2, 2.0, 0.56)
        alcohol = st.number_input("Alcohol", 8.0, 15.0, 9.4)

        if st.button("Predict Quality"):
            features = [fixed_acidity, volatile_acidity, citric_acid, residual_sugar,
                        chlorides, free_sulfur_dioxide, total_sulfur_dioxide,
                        density, pH, sulphates, alcohol]
            prediction = self.model.predict_quality(features)
            st.success(f"Predicted Wine Quality: {prediction}")

# Run the app
if __name__ == '__main__':
    app = WineApp()
    app.run()
