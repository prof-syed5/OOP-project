from Data.modules.data_collector import DataCollector
from Data.modules.data_understanding import DataUnderstanding
from Data.modules.data_preprocessing import DataPreprocessor
from Data.modules.univariate_analysis import UnivariateAnalysis
from Data.modules.bivariate_analysis import BivariateAnalysis
from Data.modules.visualiser import Visualiser
from Data.modules.model_trainer import ModelTrainer
from Data.modules.model_storage import ModelStorage

# 1. Load data
collector = DataCollector('winequality-red.csv')
data = collector.load_data()
collector.get_data_summary()

# 2. Data understanding
understanding = DataUnderstanding(data)
understanding.overview()
understanding.unique_values('quality')

# 3. Univariate analysis
uni = UnivariateAnalysis(data)
uni.histogram('alcohol')  # Example feature

# 4. Bivariate analysis
bi = BivariateAnalysis(data)
bi.correlation_heatmap()

# 5. Visualisation
viz = Visualiser(data)
viz.plot_feature_vs_target('alcohol', 'quality')  # Example plot

# 6. Preprocessing
preprocessor = DataPreprocessor(data)
X_train, X_test, y_train, y_test = preprocessor.split_data('quality')

# 7. Model training
trainer = ModelTrainer()
trainer.train(X_train, y_train)

# 8. Model evaluation
accuracy = trainer.evaluate(X_test, y_test)
print(f"\nModel Accuracy: {accuracy:.2f}")

# 9. Save model
ModelStorage.save_model(trainer.model, 'wine_model.pkl')
print("Model saved as 'wine_model.pkl'")
